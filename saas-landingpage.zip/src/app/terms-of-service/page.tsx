export default function Page() {
  return (
    <div className="p-6 rounded-md shadow">
      <h1 className="text-3xl font-bold mb-4">
        Terms of Service
      </h1>
    </div>
  )
}
